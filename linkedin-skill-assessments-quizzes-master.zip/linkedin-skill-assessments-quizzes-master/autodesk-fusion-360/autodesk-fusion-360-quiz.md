## Autodesk Fusion 360

#### Q1. How can you edit a feature?

- [ ] Select the feature, press Delete, and then create a new feature.
- [x] Right-click the feature and select Edit Feature.
- [ ] Keep clicking Undo until the feature is gone.
- [ ] Find the feature in the browser, select Remove, and then create a new feature.

#### Q2. Which tool creates a plane normal to a sketch path or edge?

- [ ] Plane Through Two Edges
- [x] Plane Along Path
- [ ] Plane at Angle
- [ ] Plane Through Three Points

